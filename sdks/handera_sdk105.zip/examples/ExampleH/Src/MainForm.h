/******************************************************************************
 *
 * File: MainForm.h
 *
 * Project : Example H
 *
 *****************************************************************************/
#ifndef _MAINFORM_H_
#define _MAINFORM_H_

#include <PalmOS.h>

Boolean MainFormHandleEvent          (EventPtr eventP);

#endif


